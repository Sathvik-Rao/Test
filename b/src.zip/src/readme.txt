macOS on VMWare on AMD

AMD will work on macos12 watch both videos
1. see video - https://www.youtube.com/watch?v=OdKhl5BiftQ (macos12) [use image]
1. see video - https://www.youtube.com/watch?v=NJ3iaYqyENc (macos14) [use .vmx, vmtools gpu memory setup(not needed)]

2. go the .vmx file
- change:
virtualHW.version = "X" to virtualHW.version = "16"

- change usb settings to 3.1 or just add:
usb_xhci.present = "TRUE"

- also add this at the end:
smc.version = "0"
cpuid.0.eax = "0000:0000:0000:0000:0000:0000:0000:1011"
cpuid.0.ebx = "0111:0101:0110:1110:0110:0101:0100:0111"
cpuid.0.ecx = "0110:1100:0110:0101:0111:0100:0110:1110"
cpuid.0.edx = "0100:1001:0110:0101:0110:1110:0110:1001"
cpuid.1.eax = "0000:0000:0000:0001:0000:0110:0111:0001"
cpuid.1.ebx = "0000:0010:0000:0001:0000:1000:0000:0000"
cpuid.1.ecx = "1000:0010:1001:1000:0010:0010:0000:0011"
cpuid.1.edx = "0000:0111:1000:1011:1111:1011:1111:1111"

*********************************************************************************************************
or using AWS for macOS

aws- https://haubenschild.medium.com/unleash-the-power-of-macos-in-the-cloud-a-step-by-step-guide-for-setting-up-an-ec2-mac-instance-55d74d688685

*********************************************************************************************************

> python -m PyInstaller --onefile --noconsole --hidden-import plyer.platforms.macos.notification --icon=logo.icns --name=ClipCascade main.py

